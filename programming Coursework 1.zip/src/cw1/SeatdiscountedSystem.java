package cw1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SeatdiscountedSystem {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		double customDiscountRate = 20.0;
		boolean CustomDiscount = false;// Determines whether it is true or false
		
	Scanner scanner = new Scanner(System.in);
	System.out.print("Specify Custom Discount Rate [Y/N] : ");// Input "Y" on keyboard to get custom discount
	String customerdiscount = scanner.next();
		
	if (customerdiscount.equals("Y")) {
		System.out.print("Specify Discount Rate (%): "); //When inputting "Y" on keyboard It allows user to input the discount Rate
		customDiscountRate = scanner.nextDouble();
		CustomDiscount = true; // 
	} else if(customerdiscount.equals("N")) { //Allows user to input "N" on keyboard to print out the Assuming discount rate
		System.out.println("Assuming Discount Rate");// Outputs Assuming Discount Rate when Inputting "N" on keyboard
	} else { 
		System.out.println("Invalid input. Assuming the default discount rate is 20.0");

		
	}
		
	double totalIncome = 0;
	double totalDiscount = 0;
	//The value of total income and total discount have not been calculated yet and are set at zero
	
	   Scanner fileScanner = new Scanner(new File("seats.txt")); { //Reads the text file line by line and is used to calculate the process
	   while (fileScanner.hasNext()) {//It returns true as scanner has another token in its input
	   String seatType = fileScanner.next();
	   double PriceOfSeats = fileScanner.nextDouble();
	   int numberOfCustomers = fileScanner.nextInt();
	  
	   // Allows programme to output seat types, the number of customer bookings and price of seats
	   double discount1 = 0;

	   if (CustomDiscount ) {
			discount1 = (PriceOfSeats * numberOfCustomers * customDiscountRate) / 100;
			} else {
				discount1 = (PriceOfSeats * numberOfCustomers * 20.0) / 100;
		//Calculates the seat type, number of bookings and seat prices
	}
  
	double income = (PriceOfSeats * numberOfCustomers)	 - discount1;
   System.out.printf("seat Type: %s , Seat Price: £%.2f, Bookings: %d, Discount £%.2f, Income: £%.2f%n",
   seatType, PriceOfSeats, numberOfCustomers, discount1, income);
   // Allows Programme to print out the seatType, Seat Price, Bookings , discount, income
   
   
  totalIncome += income;
  totalDiscount += discount1;
  
}
  System.out.printf("Total Discount: £%.2f%n", totalDiscount);
  System.out.printf("Total Income: £%.2f%n", totalIncome);
  //Programme should print out the Value of the Total Discount and Total Income
          {
	
	    }
	    }
	}

}
