package coursework2;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class SeatBookingSystem {
    private static Scanner input = new Scanner(System.in);

    // Define an array to store seat objects
    private static final Seat[] seats = new Seat[18];

    public static void main(String[] args) throws Exception {
        // Load seat information from a file
        loadSeats();

        String choice = "";
        do {
            // Display the main menu
            System.out.println("\n-- MAIN MENU --");
            System.out.println("1 - Display Seats");
            System.out.println("2 - Book Seat");
            System.out.println("3 - Cancel Seat");
            System.out.println("Q - Quit");
            System.out.print("Pick: ");
            choice = input.next().toUpperCase();

            switch (choice) {
                case "1": {
                    // Display the available seats
                    displaySeat();
                    break;
                }
                case "2": {
                    // Book a seat
                    bookSeat();
                    break;
                }
                case "3": {
                    // Cancel a booked seat
                    cancelSeat();
                    break;
                }
            }
        } while (!choice.equals("Q"));
        System.out.println("-- GOODBYE --");
    }

    // Load seat information from a file
    private static void loadSeats() throws FileNotFoundException {
        Scanner file = new Scanner(new FileReader("seats.txt"));
        int index = 0;
        String no;
        String type;
        boolean window;
        boolean aisle;
        boolean table;
        double price;
        String eMail;

        while (file.hasNext()) {
            no = file.next();
            type = file.next();
            window = file.nextBoolean();
            aisle = file.nextBoolean();
            table = file.nextBoolean();
            price = file.nextDouble();
            eMail = file.next();
            if (index < seats.length) {
                // Create a Seat object and add it to the array
                seats[index] = new Seat(no, type, window, aisle, table, price, eMail);
                index++;
            } else {
                // Handle the case where the array is full
            }
        }
        System.out.println("-- SEATS LOADED --");
    }

    // Display information about available seats
    private static void displaySeat() {
        System.out.println("-- DISPLAY SEATS --");

        for (int i = 0; i < seats.length; i++) {
            System.out.println(i + " " + seats[i].toString());
        }
    }

    // Book a seat by taking user input
    private static void bookSeat() {
        displaySeat();
        System.out.println("-- BOOK SEATS --");
        System.out.print("Enter seat number: ");
        int seatNo = input.nextInt();
        System.out.print("Enter email: ");
        String email = input.next();
        // Book the seat and display the updated information
        seats[seatNo].book(email);
        System.out.println("Seat has been booked successfully");
        displaySeat();
    }

    // Cancel a booked seat by taking user input
    private static void cancelSeat() {
        displaySeat();
        System.out.println("\n-- CANCEL A SEAT --");
        System.out.print("Enter seat number: ");
        int seatNo = input.nextInt();
        if (seats[seatNo].geteMail().equals("free")) {
            System.out.println("This seat has not been booked");
        } else {
            // Cancel the booked seat and display the updated information
            seats[seatNo].cancel();
            System.out.println("This seat has been cancelled");
        }
    }
}


 
