package coursework2;

// The Seat class represents a seat in a seating system, with various attributes such as seat number, type, and availability.

public class Seat {

    // Instance variables to store information about the seat.
    String no;       // Seat number
    String type;     // Type of seat 
    boolean window;  // Indicates if the seat is by the window
    boolean aisle;   // Indicates if the seat is in the aisle
    boolean table;   // Indicates if the seat has a table
    double price;    // Price of the seat
    String eMail;    // Email associated with the seat reservation

    // Constructor to initialise the Seat object with provided values.
    public Seat(String no, String type, boolean window, boolean aisle, boolean table, double price, String eMail) {
        this.no = no;
        this.type = type;
        this.window = window;
        this.aisle = aisle;
        this.table = table;
        this.price = price;
        this.eMail = eMail;
    }

    // Override the toString method to provide a formatted string representation of the Seat object.
    public String toString() {
        String result = no + " " + type + " " + window + " " + aisle + " " + table + " " + price + " " + eMail;
        return result;
    }

    // Override the equals method to compare two Seat objects based on seat number and type.
    public boolean equals(Seat s) {
        boolean result = false;
        if (this.no.equals(s.no) && this.type.equals(s.type)) {
            result = true;
        }
        return result;
    }

    // Method to book the seat with the given email.
    public void book(String eMail) {
        this.eMail = eMail;
    }

    // Method to cancel the seat reservation and set the email to "free".
    public void cancel() {
        this.eMail = "free";
    }

    // Method to get the email associated with the seat.
    public String geteMail() {
        return eMail;
    }
}





